$(document).ready(function(){
  //TODO: Control multiple times deployments
  mainApp.init();
});