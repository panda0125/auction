var mainApp = new mainApplication();
