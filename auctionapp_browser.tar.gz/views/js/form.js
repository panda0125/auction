$(document).ready(function(){
	formApp.init();
});